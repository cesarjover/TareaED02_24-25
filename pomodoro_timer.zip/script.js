let workTime = 25 * 60;
let breakTime = 5 * 60;
let time = workTime;
let isRunning = false;
let isWork = true;
let timerInterval;

const timerDisplay = document.getElementById("timer");
const modeDisplay = document.getElementById("mode");
const startBtn = document.getElementById("start");
const pauseBtn = document.getElementById("pause");
const resetBtn = document.getElementById("reset");

function updateTimerDisplay() {
  let minutes = Math.floor(time / 60);
  let seconds = time % 60;
  timerDisplay.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function switchMode() {
  isWork = !isWork;
  time = isWork ? workTime : breakTime;
  modeDisplay.textContent = `Modo: ${isWork ? "Trabajo" : "Descanso"}`;
  updateTimerDisplay();
}

function startTimer() {
  if (!isRunning) {
    isRunning = true;
    timerInterval = setInterval(() => {
      if (time > 0) {
        time--;
        updateTimerDisplay();
      } else {
        clearInterval(timerInterval);
        isRunning = false;
        switchMode();
        startTimer(); // auto-continuar con siguiente ciclo
      }
    }, 1000);
  }
}

function pauseTimer() {
  clearInterval(timerInterval);
  isRunning = false;
}

function resetTimer() {
  clearInterval(timerInterval);
  isRunning = false;
  time = isWork ? workTime : breakTime;
  updateTimerDisplay();
}

startBtn.addEventListener("click", startTimer);
pauseBtn.addEventListener("click", pauseTimer);
resetBtn.addEventListener("click", resetTimer);

updateTimerDisplay();
